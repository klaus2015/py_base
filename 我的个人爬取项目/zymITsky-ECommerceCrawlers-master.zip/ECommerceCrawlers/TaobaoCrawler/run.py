from cookiepool.scheduler import Scheduler

if __name__ == '__main__':

    Scheduler().run()
