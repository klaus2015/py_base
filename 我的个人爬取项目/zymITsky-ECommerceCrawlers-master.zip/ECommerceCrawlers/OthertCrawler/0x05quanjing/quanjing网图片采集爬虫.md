
## 爬虫图片练习任务

网站链接：[全景网](https://www.quanjing.com)

### 爬取目标网站：[https://www.quanjing.com/category/1286521/77.html](https://www.quanjing.com/category/1286521/77.html)

### 爬虫分析

将此网站的本链接下面的1万张‘中东人’图片爬取下来，保存到本地
![](https://raw.githubusercontent.com/Hatcat123/GraphicBed/master/Img/20190411223911.png)

**爬虫要求：尝试使用多线程、多进程、异步协程等任意一种方式去加快爬取速度，或使用更快的爬虫框架。我们尝试降低爬虫时间。计算爬取的时间，将爬虫用的大概时间在最后的文档或代码中标注。**

致力于使用最小的时间爬取此链接的所有图片

### 获取结果

将图片保存到本地的某个文件夹中