
关于微信的公众号的爬取，等忙完这一阵子，将会推出

部分内容功能将进行二次开发，推出商业版，自媒体的朋友可以先联系使用

![](https://raw.githubusercontent.com/Hatcat123/GraphicBed/master/Img/20190515130702.png)
