
## 搜狐及时新闻采集——适合机器学习样本采集使用

### 爬取方式

![](https://raw.githubusercontent.com/Hatcat123/GraphicBed/master/Img/20190512203013.jpg)


### 结构设计

略

### 使用框架

略

### 演示：

![](https://raw.githubusercontent.com/Hatcat123/GraphicBed/master/Img/20190512202741.jpg)

**更新功能**

![](https://raw.githubusercontent.com/Hatcat123/GraphicBed/master/Img/20190520213812.gif)





