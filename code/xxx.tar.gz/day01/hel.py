"""
汇率轉換器

"""

# 获取需求


str_usr = input("请输入美元： ")
# 逻辑处理
result = float(str_usr) * 6.09
# 3.显示结果
print("结果是：",result)

# print(5 // 2)
# print(5 / 2)
# print(27 % 10)
